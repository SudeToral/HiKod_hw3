import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(MyApp());
}

class Task {
  final String name;
  final String description;
  final String start_date;
  final String end_date;

  Task(this.name, this.description, this.start_date, this.end_date);
}

class TaskList with ChangeNotifier {
  List<Task> tasks = [];

  TaskList() {
    tasks.add(Task('Math', 'homework', '6 January', '7 January'));
    tasks.add(Task('Physic', 'homework', '6 January', '8 January'));
    tasks.add(Task('Chemistry', 'homework', '6 January', '9 January'));
    tasks.add(Task('Turkish', 'homework', '8 January', '10 January'));
  }

  void addTask(String name, String description, String startDate, String endDate) {
    final newTask = Task(name, description, startDate, endDate);
    tasks.add(newTask);
    notifyListeners();
  }
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => TaskList(),
      child: MaterialApp(
        home: TaskListScreen(),
      ),
    );
  }
}

class TaskListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final taskListProvider = Provider.of<TaskList>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Task List'),
      ),
      body: Column(
        children: [
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AddTaskScreen()),
              );
            },
            child: const Text('Add Task'),
          ),
          Expanded(
            child: Builder(
              builder: (context) {
                final taskListProvider = Provider.of<TaskList>(context);
                return ListView.builder(
                  itemCount: taskListProvider.tasks.length,
                  itemBuilder: (context, index) {
                    final task = taskListProvider.tasks[index];
                    return Dismissible(
                      key: Key(task.name),
                      direction: DismissDirection.endToStart,
                      onDismissed: (direction) {
                        taskListProvider.tasks.removeAt(index);
                      },
                      child: ListTile(
                        title: Text(task.name),
                        subtitle: Text(task.description),
                        trailing: Text('Start Date: ${task.start_date} - End Date: ${task.end_date}'),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class AddTaskScreen extends StatefulWidget {
  @override
  _AddTaskScreenState createState() => _AddTaskScreenState();
}

class _AddTaskScreenState extends State<AddTaskScreen> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController descriptionController = TextEditingController();
  final TextEditingController startDateController = TextEditingController();
  final TextEditingController endDateController = TextEditingController();

  @override
  void dispose() {
    nameController.dispose();
    descriptionController.dispose();
    startDateController.dispose();
    endDateController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Task'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: nameController,
              decoration: InputDecoration(labelText: 'Task Name'),
            ),
            TextField(
              controller: descriptionController,
              decoration: InputDecoration(labelText: 'Declaration'),
            ),
            TextField(
              controller: startDateController,
              decoration: InputDecoration(labelText: 'Start Date'),
            ),
            TextField(
              controller: endDateController,
              decoration: InputDecoration(labelText: 'End Date'),
            ),
            ElevatedButton(
              onPressed: () {
                final taskListProvider = Provider.of<TaskList>(context, listen: false);
                taskListProvider.addTask(
                  nameController.text,
                  descriptionController.text,
                  startDateController.text,
                  endDateController.text,
                );

                nameController.clear();
                descriptionController.clear();
                startDateController.clear();
                endDateController.clear();

                Navigator.pop(context);
              },
              child: const Text('Görev Ekle'),
            ),
          ],
        ),
      ),
    );
  }
}
